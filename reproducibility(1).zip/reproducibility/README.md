# Reproducibility materials for DSS-ADMM

This directory contains a self-contained Python implementation of the algorithm
and experiment drivers for **Distributed Stochastic Smoothing ADMM for Penalized
Quantile Regression**.

## Environment

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

A Conda specification is also supplied in `environment.yml`.

## Fast integrity check

```bash
./run_smoke.sh
```

This executes a deterministic small distributed problem, writes
`results/smoke_test_results.csv` and `.json`, and checks that all coefficients
and reported quantities are finite.

## Reproduce the experiment families

Run the complete suite:

```bash
./run_all.sh
```

Run a faster validation suite:

```bash
python code/run_experiments.py --quick --experiment all
python code/run_extended_experiments.py --quick --experiment all
python code/verify_outputs.py
```

The additional Figure 4--8 studies are implemented in `code/run_extended_experiments.py`.

Run one core experiment family:

```bash
python code/run_experiments.py --experiment convergence
python code/run_experiments.py --experiment replicates
python code/run_experiments.py --experiment heterogeneity
python code/run_experiments.py --experiment scaling
python code/run_experiments.py --experiment nonconvex
python code/run_experiments.py --experiment diabetes
python code/run_experiments.py --experiment engel
```

All random seeds are explicit in `code/run_experiments.py`. The diabetes data
are shipped with scikit-learn and the Engel data are shipped with statsmodels;
no external download is required for either real-data experiment.

## Outputs

- `results/`: outputs produced by the included validation runs or by a new run.
- `figures/`: figures produced by a new run.
- `precomputed_results/`: table values reported in the manuscript, stored as
  machine-readable CSV files.
- `precomputed_figures/`: the exact publication figures used in the manuscript.
- `code/figure1_source.tex`: exact TikZ source for the color-only revision of
  Figure 1; the node coordinates, labels, laptop bases, and arrows are retained
  from Revision 12.

The manuscript's table values are preserved separately from a quick validation
run because the manuscript uses its stated replication counts, whereas
`--quick` deliberately uses fewer replications. The code implements the same
DSS-ADMM updates and data-generating mechanisms and can be run with the full
settings to regenerate the complete experiment families.

## Interpretation of computation time

The code emulates synchronous horizontal distributed learning in one Python
process. It reproduces numerical behavior, sample-gradient counts, consensus,
and serial computation time. It does not claim physical multi-node wall-clock
speedup or network latency measurements.

### Extended sensitivity families

```bash
python code/run_extended_experiments.py --experiment worker-smoothing
python code/run_extended_experiments.py --experiment regularization-batch
python code/run_extended_experiments.py --experiment robustness-dimension
python code/run_extended_experiments.py --experiment imbalance-correlation
python code/run_extended_experiments.py --experiment nonconvex-schedules
```
