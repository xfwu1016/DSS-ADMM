#!/usr/bin/env python3
"""Extended sensitivity experiments for DSS-ADMM Figures 4--8.

The core optimizer and data-generating functions are imported from
``run_experiments.py``.  This file makes every additional manuscript study
explicit: worker count, smoothing, regularization/batch interaction, error
robustness, dimensional scaling, unequal site sizes, predictor correlation,
and weakly-convex stationarity under fixed/increasing/full batches.
"""
from __future__ import annotations

import argparse
import math
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from run_experiments import (
    FIG_DIR,
    RES_DIR,
    fss_admm,
    make_synth,
    prox_penalty,
    psi_tau_mu,
    selection_metrics,
    split_workers,
)


def _mean_sd(frame: pd.DataFrame, keys: list[str], values: list[str]) -> pd.DataFrame:
    aggs = {}
    for value in values:
        aggs[value + "_mean"] = (value, "mean")
        aggs[value + "_sd"] = (value, "std")
    return frame.groupby(keys, sort=False).agg(**aggs).reset_index()


def _save(fig: plt.Figure, name: str) -> None:
    fig.tight_layout()
    fig.savefig(Path(FIG_DIR) / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(Path(FIG_DIR) / f"{name}.png", dpi=350, bbox_inches="tight")
    plt.close(fig)


def run_worker_and_smoothing(replicates: int = 5) -> pd.DataFrame:
    rows: list[dict] = []
    total_batch = 128
    for seed in range(replicates):
        Xtr, ytr, Xte, yte, _ = make_synth(seed=100 + seed, n=2000, p=100, s=10, error="contaminated")
        for workers_n in [2, 4, 8, 16]:
            workers = split_workers(Xtr, ytr, workers_n, seed=200 + seed)
            fit = fss_admm(
                workers, tau=0.5, lam=0.04, mu=0.08,
                batch=max(1, total_batch // workers_n), iterations=450,
                seed=300 + seed, noise_scale=0.12,
                eval_data=(Xtr, ytr, Xte, yte), eval_every=450,
            )
            last = fit.history.iloc[-1]
            rows.append({"study": "workers", "replicate": seed, "workers": workers_n,
                         "parameter": workers_n, "test_loss": last.test_pinball,
                         "consensus": last.consensus, "objective": last.objective})
        workers = split_workers(Xtr, ytr, 8, seed=200 + seed)
        for mu in [0.025, 0.05, 0.08, 0.12, 0.20]:
            fit = fss_admm(
                workers, tau=0.5, lam=0.02, mu=mu, batch=16,
                iterations=450, seed=400 + seed, noise_scale=0.12,
                eval_data=(Xtr, ytr, Xte, yte), eval_every=450,
            )
            last = fit.history.iloc[-1]
            rows.append({"study": "smoothing", "replicate": seed, "workers": 8,
                         "parameter": mu, "test_loss": last.test_pinball,
                         "consensus": last.consensus, "objective": last.objective})
    df = pd.DataFrame(rows)
    df.to_csv(Path(RES_DIR) / "worker_smoothing_results.csv", index=False)
    summary = _mean_sd(df, ["study", "parameter"], ["test_loss", "consensus", "objective"])
    summary.to_csv(Path(RES_DIR) / "worker_smoothing_summary.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.3))
    w = summary[summary.study == "workers"]
    axes[0].errorbar(w.parameter, w.test_loss_mean, yerr=w.test_loss_sd, marker="o", label="Test loss")
    ax2 = axes[0].twinx()
    ax2.errorbar(w.parameter, w.consensus_mean, yerr=w.consensus_sd, marker="s", linestyle="--", label="Consensus")
    axes[0].set_xlabel("Workers")
    axes[0].set_ylabel("Test loss")
    ax2.set_ylabel("Consensus residual")
    s = summary[summary.study == "smoothing"]
    axes[1].errorbar(s.parameter, s.test_loss_mean, yerr=s.test_loss_sd, marker="o", label="Test loss")
    axes[1].errorbar(s.parameter, s.objective_mean, yerr=s.objective_sd, marker="s", linestyle="--", label="Original objective")
    axes[1].set_xlabel("Smoothing parameter")
    axes[1].set_ylabel("Value")
    axes[1].legend(frameon=False, fontsize=8)
    _save(fig, "Fig4_worker_smoothing")
    return summary


def run_regularization_batch(replicates: int = 5) -> pd.DataFrame:
    rows: list[dict] = []
    lambdas = [0.005, 0.01, 0.02, 0.04, 0.08]
    batches = [("16", 16), ("64", 64), ("Full", None)]
    for seed in range(replicates):
        Xtr, ytr, Xte, yte, beta_true = make_synth(seed=500 + seed, n=2000, p=100, s=10, error="contaminated")
        workers = split_workers(Xtr, ytr, 8, seed=600 + seed)
        for batch_name, batch in batches:
            for lam in lambdas:
                fit = fss_admm(
                    workers, tau=0.5, lam=lam, mu=0.08, batch=batch,
                    iterations=450, seed=700 + seed, noise_scale=0.12,
                    eval_data=(Xtr, ytr, Xte, yte), eval_every=450,
                )
                last = fit.history.iloc[-1]
                _, _, f1 = selection_metrics(fit.coefficient, beta_true)
                rows.append({"replicate": seed, "batch": batch_name, "lambda": lam,
                             "test_loss": last.test_pinball, "selection_f1": f1,
                             "consensus": last.consensus})
    df = pd.DataFrame(rows)
    df.to_csv(Path(RES_DIR) / "regularization_batch_results.csv", index=False)
    summary = _mean_sd(df, ["batch", "lambda"], ["test_loss", "selection_f1", "consensus"])
    summary.to_csv(Path(RES_DIR) / "regularization_batch_summary.csv", index=False)

    order = ["16", "64", "Full"]
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.4))
    for ax, value, title in [(axes[0], "test_loss_mean", "Test loss"), (axes[1], "selection_f1_mean", "Selection F1")]:
        matrix = summary.pivot(index="batch", columns="lambda", values=value).reindex(order)
        image = ax.imshow(matrix.to_numpy(), aspect="auto", origin="upper")
        ax.set_yticks(range(len(order)), order)
        ax.set_xticks(range(len(matrix.columns)), [f"{x:g}" for x in matrix.columns])
        ax.set_xlabel("Regularization level")
        ax.set_ylabel("Batch size")
        ax.set_title(title)
        fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    _save(fig, "Fig5_regularization_batch")
    return summary


def run_robustness_dimension(replicates: int = 3) -> pd.DataFrame:
    rows: list[dict] = []
    for error in ["gaussian", "t3", "laplace", "contaminated"]:
        generator_error = "normal" if error == "gaussian" else error
        for tau in [0.25, 0.50, 0.75]:
            for seed in range(replicates):
                Xtr, ytr, Xte, yte, _ = make_synth(seed=800 + seed, n=1800, p=80, s=8, error=generator_error)
                workers = split_workers(Xtr, ytr, 8, seed=900 + seed)
                fit = fss_admm(workers, tau=tau, lam=0.02, mu=0.08, batch=16,
                               iterations=400, seed=1000 + seed, noise_scale=0.12,
                               eval_data=(Xtr, ytr, Xte, yte), eval_every=400)
                last = fit.history.iloc[-1]
                rows.append({"study": "error", "error": error, "tau": tau,
                             "replicate": seed, "test_loss": last.test_pinball,
                             "time_seconds": last.time_seconds, "consensus": last.consensus})
    for p in [40, 80, 160, 320]:
        for seed in range(replicates):
            Xtr, ytr, Xte, yte, _ = make_synth(seed=1100 + seed, n=1800, p=p, s=min(10, p // 4), error="contaminated")
            workers = split_workers(Xtr, ytr, 8, seed=1200 + seed)
            fit = fss_admm(workers, tau=0.5, lam=0.02, mu=0.08, batch=16,
                           iterations=350, seed=1300 + seed, noise_scale=0.12,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=350)
            last = fit.history.iloc[-1]
            rows.append({"study": "dimension", "features": p, "replicate": seed,
                         "test_loss": last.test_pinball, "time_seconds": last.time_seconds,
                         "consensus": last.consensus})
    df = pd.DataFrame(rows)
    df.to_csv(Path(RES_DIR) / "robustness_dimension_results.csv", index=False)
    err = _mean_sd(df[df.study == "error"], ["error", "tau"], ["test_loss"])
    dim = _mean_sd(df[df.study == "dimension"], ["features"], ["time_seconds", "consensus"])
    err.to_csv(Path(RES_DIR) / "error_robustness_summary.csv", index=False)
    dim.to_csv(Path(RES_DIR) / "dimension_scaling_summary.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.3))
    for error in err.error.drop_duplicates():
        q = err[err.error == error]
        axes[0].errorbar(q.tau, q.test_loss_mean, yerr=q.test_loss_sd, marker="o", label=error)
    axes[0].set_xlabel("Quantile")
    axes[0].set_ylabel("Test loss")
    axes[0].legend(frameon=False, fontsize=7)
    axes[1].errorbar(dim.features, dim.time_seconds_mean, yerr=dim.time_seconds_sd, marker="s", label="Time")
    ax2 = axes[1].twinx()
    ax2.errorbar(dim.features, dim.consensus_mean, yerr=dim.consensus_sd, marker="o", linestyle="--", label="Consensus")
    axes[1].set_xlabel("Features")
    axes[1].set_ylabel("Serial time (s)")
    ax2.set_ylabel("Consensus residual")
    _save(fig, "Fig6_robustness_dimension")
    return pd.concat([err.assign(study="error"), dim.assign(study="dimension")], ignore_index=True)


def _split_by_proportions(X: np.ndarray, y: np.ndarray, proportions: list[float], seed: int) -> list[tuple[np.ndarray, np.ndarray]]:
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(y))
    raw = np.asarray(proportions, dtype=float)
    raw /= raw.sum()
    counts = np.floor(raw * len(y)).astype(int)
    counts[-1] += len(y) - counts.sum()
    cuts = np.cumsum(counts)[:-1]
    return [(X[idx], y[idx]) for idx in np.split(order, cuts)]


def run_imbalance_correlation(replicates: int = 5) -> pd.DataFrame:
    rows: list[dict] = []
    profiles = {
        "Balanced": [1, 1, 1, 1, 1, 1, 1, 1],
        "Moderate": [1, 1, 1, 1, 2, 2, 2, 2],
        "Severe": [1, 1, 1, 2, 2, 4, 4, 8],
    }
    for seed in range(replicates):
        Xtr, ytr, Xte, yte, beta_true = make_synth(seed=1400 + seed, n=2200, p=100, s=10, error="contaminated")
        for label, profile in profiles.items():
            workers = _split_by_proportions(Xtr, ytr, profile, 1500 + seed)
            fit = fss_admm(workers, tau=0.5, lam=0.02, mu=0.08, batch=16,
                           iterations=450, seed=1600 + seed, noise_scale=0.12,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=450)
            last = fit.history.iloc[-1]
            rows.append({"study": "imbalance", "level": label, "replicate": seed,
                         "test_loss": last.test_pinball, "consensus": last.consensus,
                         "selection_f1": selection_metrics(fit.coefficient, beta_true)[2]})
        for corr in [0.0, 0.3, 0.6, 0.9]:
            Xtr, ytr, Xte, yte, beta_true = make_synth(seed=1700 + seed, n=2200, p=100, s=10,
                                                       correlation=corr, error="contaminated")
            workers = split_workers(Xtr, ytr, 8, seed=1800 + seed)
            fit = fss_admm(workers, tau=0.5, lam=0.02, mu=0.08, batch=16,
                           iterations=450, seed=1900 + seed, noise_scale=0.12,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=450)
            last = fit.history.iloc[-1]
            rows.append({"study": "correlation", "correlation": corr, "replicate": seed,
                         "test_loss": last.test_pinball, "consensus": last.consensus,
                         "selection_f1": selection_metrics(fit.coefficient, beta_true)[2]})
    df = pd.DataFrame(rows)
    df.to_csv(Path(RES_DIR) / "imbalance_correlation_results.csv", index=False)
    imb = _mean_sd(df[df.study == "imbalance"], ["level"], ["test_loss", "consensus", "selection_f1"])
    cor = _mean_sd(df[df.study == "correlation"], ["correlation"], ["test_loss", "consensus", "selection_f1"])
    imb.to_csv(Path(RES_DIR) / "imbalance_summary.csv", index=False)
    cor.to_csv(Path(RES_DIR) / "correlation_summary.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.3))
    order = ["Balanced", "Moderate", "Severe"]
    imb = imb.set_index("level").loc[order].reset_index()
    axes[0].errorbar(range(3), imb.test_loss_mean, yerr=imb.test_loss_sd, marker="o", label="Test loss")
    ax0b = axes[0].twinx()
    ax0b.errorbar(range(3), imb.consensus_mean, yerr=imb.consensus_sd, marker="s", linestyle="--", label="Consensus")
    axes[0].set_xticks(range(3), order, rotation=10)
    axes[0].set_ylabel("Test loss")
    ax0b.set_ylabel("Consensus residual")
    axes[1].errorbar(cor.correlation, cor.test_loss_mean, yerr=cor.test_loss_sd, marker="o", label="Test loss")
    ax1b = axes[1].twinx()
    ax1b.errorbar(cor.correlation, cor.selection_f1_mean, yerr=cor.selection_f1_sd, marker="s", linestyle="--", label="Selection F1")
    axes[1].set_xlabel("AR(1) correlation")
    axes[1].set_ylabel("Test loss")
    ax1b.set_ylabel("Selection F1")
    _save(fig, "Fig7_imbalance_correlation")
    return pd.concat([imb.assign(study="imbalance"), cor.assign(study="correlation")], ignore_index=True)


def _full_gradient_mapping(beta: np.ndarray, workers: list[tuple[np.ndarray, np.ndarray]], tau: float,
                           mu: float, penalty: str, lam: float, concavity: float) -> float:
    total = sum(len(y) for _, y in workers)
    grad = np.zeros_like(beta)
    for X, y in workers:
        weight = len(y) / total
        residual = y - X @ beta
        grad += weight * (-(X.T @ psi_tau_mu(residual, tau, mu)) / len(y))
    step = 0.25
    prox = prox_penalty(beta - step * grad, penalty, lam, quadratic=1.0 / step, concavity=concavity)
    return float(np.linalg.norm((beta - prox) / step))


def run_nonconvex_batch_schedules(replicates: int = 5, iterations: int = 500) -> pd.DataFrame:
    rows: list[dict] = []
    schedules = {
        "Fixed 16": 16,
        "Increasing": lambda k, n: min(n, int(math.ceil(8.0 * math.sqrt(k + 1.0)))),
        "Full": None,
    }
    for seed in range(replicates):
        Xtr, ytr, Xte, yte, _ = make_synth(seed=2000 + seed, n=1200, p=80, s=8, error="contaminated")
        workers = split_workers(Xtr, ytr, 8, seed=2100 + seed)
        for penalty in ["mcp", "scad"]:
            for schedule_name, batch in schedules.items():
                fit = fss_admm(workers, tau=0.5, lam=0.025, mu=0.08, admm_penalty=1.0,
                               batch=batch, iterations=iterations, seed=2200 + seed,
                               penalty=penalty, concavity=3.7, noise_scale=0.12,
                               eval_data=(Xtr, ytr, Xte, yte), eval_every=500)
                last = fit.history.iloc[-1]
                mapping = _full_gradient_mapping(fit.coefficient, workers, 0.5, 0.08, penalty, 0.025, 3.7)
                residual = math.sqrt(mapping * mapping + float(last.consensus) ** 2)
                rows.append({"replicate": seed, "penalty": penalty.upper(), "schedule": schedule_name,
                             "kkt_residual": residual, "test_loss": last.test_pinball,
                             "sample_gradients": last.samples_accessed})
    df = pd.DataFrame(rows)
    df.to_csv(Path(RES_DIR) / "nonconvex_batch_schedule_results.csv", index=False)
    summary = _mean_sd(df, ["penalty", "schedule"], ["kkt_residual", "test_loss", "sample_gradients"])
    summary.to_csv(Path(RES_DIR) / "nonconvex_batch_schedule_summary.csv", index=False)

    order = ["Fixed 16", "Increasing", "Full"]
    x = np.arange(len(order))
    width = 0.35
    fig, ax = plt.subplots(figsize=(6.2, 3.4))
    for j, penalty in enumerate(["MCP", "SCAD"]):
        q = summary[summary.penalty == penalty].set_index("schedule").loc[order]
        ax.bar(x + (j - 0.5) * width, q.kkt_residual_mean, width, yerr=q.kkt_residual_sd, label=penalty, capsize=3)
    ax.set_xticks(x, order)
    ax.set_ylabel("Full-gradient KKT residual")
    ax.legend(frameon=False)
    _save(fig, "Fig8_nonconvex_kkt")
    return summary


def main(quick: bool, experiment: str) -> None:
    reps = 2 if quick else 5
    started = time.perf_counter()
    if experiment in {"all", "worker-smoothing"}:
        run_worker_and_smoothing(reps)
    if experiment in {"all", "regularization-batch"}:
        run_regularization_batch(reps)
    if experiment in {"all", "robustness-dimension"}:
        run_robustness_dimension(2 if quick else 3)
    if experiment in {"all", "imbalance-correlation"}:
        run_imbalance_correlation(reps)
    if experiment in {"all", "nonconvex-schedules"}:
        run_nonconvex_batch_schedules(1 if quick else reps, 150 if quick else 500)
    print(f"Extended experiments completed in {time.perf_counter() - started:.2f} seconds")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extended DSS-ADMM sensitivity experiments")
    parser.add_argument("--quick", action="store_true", help="Use fewer replications for validation")
    parser.add_argument("--experiment", choices=["all", "worker-smoothing", "regularization-batch",
                                                   "robustness-dimension", "imbalance-correlation",
                                                   "nonconvex-schedules"], default="all")
    args = parser.parse_args()
    main(args.quick, args.experiment)
