#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error figure1_source.tex
mkdir -p ../figures
cp figure1_source.pdf ../figures/Fig1.pdf
printf 'Generated %s\n' "$(cd ../figures && pwd)/Fig1.pdf"
