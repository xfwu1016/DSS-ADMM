"""Reproducible experiments for
Distributed stochastic smoothing ADMM for penalized quantile regression.

The code emulates synchronous horizontal federated learning on one machine.
No raw observations are exchanged by the algorithm: each worker computes a
mini-batch stochastic gradient locally and communicates one coefficient vector.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import platform
import time
from dataclasses import dataclass
from typing import Callable, Iterable, List, Optional, Sequence, Tuple, Union

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    import sklearn
    from sklearn.datasets import load_diabetes
    from sklearn.linear_model import QuantileRegressor
    from sklearn.model_selection import train_test_split
    SKLEARN_OK = True
except Exception:
    sklearn = None
    SKLEARN_OK = False

try:
    import statsmodels.api as sm
    STATSMODELS_OK = True
except Exception:
    sm = None
    STATSMODELS_OK = False

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG_DIR = os.path.join(ROOT, "figures")
RES_DIR = os.path.join(ROOT, "results")
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(RES_DIR, exist_ok=True)

Array = np.ndarray
BatchSpec = Union[int, None, Callable[[int, int], int]]


def check_loss(u: Array, tau: float) -> Array:
    return np.where(u >= 0.0, tau * u, (tau - 1.0) * u)


def smooth_abs(u: Array, mu: float) -> Array:
    au = np.abs(u)
    return np.where(au >= mu, au, u * u / (2.0 * mu) + mu / 2.0)


def smooth_abs_prime(u: Array, mu: float) -> Array:
    out = np.sign(u)
    inside = np.abs(u) < mu
    out[inside] = u[inside] / mu
    return out


def smooth_check(u: Array, tau: float, mu: float) -> Array:
    return 0.5 * (smooth_abs(u, mu) + (2.0 * tau - 1.0) * u)


def psi_tau_mu(u: Array, tau: float, mu: float) -> Array:
    return 0.5 * (smooth_abs_prime(u, mu) + 2.0 * tau - 1.0)


def soft_threshold(v: Array, threshold: float) -> Array:
    return np.sign(v) * np.maximum(np.abs(v) - threshold, 0.0)


def penalty_value(beta: Array, penalty: str, lam: float, alpha: float = 0.8,
                  concavity: float = 3.7) -> float:
    t = np.abs(beta)
    if penalty == "lasso":
        return float(lam * np.sum(t))
    if penalty == "elastic":
        return float(lam * (alpha * np.sum(t) + 0.5 * (1.0 - alpha) * np.dot(beta, beta)))
    if penalty == "mcp":
        a = concavity
        vals = np.where(t <= a * lam, lam * t - t * t / (2.0 * a), 0.5 * a * lam * lam)
        return float(np.sum(vals))
    if penalty == "scad":
        a = concavity
        vals = np.empty_like(t)
        r1 = t <= lam
        r2 = (t > lam) & (t <= a * lam)
        vals[r1] = lam * t[r1]
        vals[r2] = (-t[r2] ** 2 + 2.0 * a * lam * t[r2] - lam * lam) / (2.0 * (a - 1.0))
        vals[~(r1 | r2)] = 0.5 * (a + 1.0) * lam * lam
        return float(np.sum(vals))
    raise ValueError(f"Unknown penalty: {penalty}")


def prox_penalty(v: Array, penalty: str, lam: float, quadratic: float,
                 alpha: float = 0.8, concavity: float = 3.7) -> Array:
    """Minimize P(z)+(quadratic/2)||z-v||^2 coordinatewise.

    For MCP/SCAD, candidate minimizers from every smooth piece and all
    boundaries are evaluated. The weak-convexity requirement is
    quadratic > 1/a (MCP) or quadratic > 1/(a-1) (SCAD).
    """
    if quadratic <= 0:
        raise ValueError("quadratic must be positive")
    if penalty == "lasso":
        return soft_threshold(v, lam / quadratic)
    if penalty == "elastic":
        return soft_threshold(v, lam * alpha / quadratic) / (1.0 + lam * (1.0 - alpha) / quadratic)
    if penalty not in {"mcp", "scad"}:
        raise ValueError(f"Unknown penalty: {penalty}")

    a = concavity
    if penalty == "mcp" and quadratic <= 1.0 / a:
        raise ValueError("MCP proximal subproblem is not strongly convex: increase ADMM penalty")
    if penalty == "scad" and quadratic <= 1.0 / (a - 1.0):
        raise ValueError("SCAD proximal subproblem is not strongly convex: increase ADMM penalty")

    out = np.zeros_like(v)
    for j, value in enumerate(v):
        sgn = 1.0 if value >= 0.0 else -1.0
        w = abs(float(value))
        candidates = [0.0]
        if penalty == "mcp":
            # Stationary point in [0,a*lam].
            t = (quadratic * w - lam) / (quadratic - 1.0 / a)
            candidates.extend([min(max(t, 0.0), a * lam), a * lam, w])
        else:
            # Region 1: [0,lam].
            t1 = w - lam / quadratic
            candidates.extend([min(max(t1, 0.0), lam), lam])
            # Region 2: [lam,a*lam].
            t2 = (quadratic * w - a * lam / (a - 1.0)) / (quadratic - 1.0 / (a - 1.0))
            candidates.extend([min(max(t2, lam), a * lam), a * lam, w])

        best_t = 0.0
        best_val = math.inf
        for t in candidates:
            t = max(float(t), 0.0)
            pval = penalty_value(np.array([t]), penalty, lam, alpha=alpha, concavity=a)
            obj = pval + 0.5 * quadratic * (t - w) ** 2
            if obj < best_val:
                best_val = obj
                best_t = t
        out[j] = sgn * best_t
    return out


def pinball_objective(beta: Array, X: Array, y: Array, tau: float, lam: float,
                      penalty: str = "lasso", alpha: float = 0.8,
                      concavity: float = 3.7) -> float:
    return float(np.mean(check_loss(y - X @ beta, tau)) +
                 penalty_value(beta, penalty, lam, alpha, concavity))


def smooth_objective(beta: Array, X: Array, y: Array, tau: float, mu: float,
                     lam: float, penalty: str = "lasso", alpha: float = 0.8,
                     concavity: float = 3.7) -> float:
    return float(np.mean(smooth_check(y - X @ beta, tau, mu)) +
                 penalty_value(beta, penalty, lam, alpha, concavity))


def test_pinball(beta: Array, X: Array, y: Array, tau: float) -> float:
    return float(np.mean(check_loss(y - X @ beta, tau)))


def standardize_train_test(Xtr: Array, Xte: Array) -> Tuple[Array, Array]:
    mean = Xtr.mean(axis=0)
    std = Xtr.std(axis=0)
    std[std < 1e-10] = 1.0
    return (Xtr - mean) / std, (Xte - mean) / std


def standardize_y(ytr: Array, yte: Array) -> Tuple[Array, Array]:
    mean = float(ytr.mean())
    std = float(ytr.std())
    if std < 1e-10:
        std = 1.0
    return (ytr - mean) / std, (yte - mean) / std


def make_synth(seed: int = 0, n: int = 2000, p: int = 100, s: int = 10,
               correlation: float = 0.3, heteroscedastic: bool = True,
               error: str = "t3") -> Tuple[Array, Array, Array, Array, Array]:
    rng = np.random.default_rng(seed)
    idx = np.arange(p)
    cov = correlation ** np.abs(np.subtract.outer(idx, idx))
    chol = np.linalg.cholesky(cov + 1e-8 * np.eye(p))
    X = rng.normal(size=(n, p)) @ chol.T
    beta = np.zeros(p)
    beta[:s] = rng.choice([-1.0, 1.0], size=s) * rng.uniform(0.8, 1.6, size=s)
    signal = X @ beta
    if error == "t3":
        eps = rng.standard_t(3, size=n) / math.sqrt(3.0)
    elif error == "contaminated":
        eps = rng.normal(size=n)
        mask = rng.uniform(size=n) < 0.08
        eps[mask] += rng.normal(scale=7.0, size=int(mask.sum()))
    elif error == "laplace":
        eps = rng.laplace(size=n) / math.sqrt(2.0)
    else:
        eps = rng.normal(size=n)
    if heteroscedastic:
        eps = (0.45 + 0.45 * np.abs(X[:, 0])) * eps
    y = signal + eps
    perm = rng.permutation(n)
    ntr = int(0.75 * n)
    tr, te = perm[:ntr], perm[ntr:]
    Xtr, Xte = standardize_train_test(X[tr], X[te])
    ytr, yte = standardize_y(y[tr], y[te])
    return Xtr, ytr, Xte, yte, beta


def split_workers(X: Array, y: Array, workers: int, seed: int = 0,
                  non_iid: bool = False) -> List[Tuple[Array, Array]]:
    rng = np.random.default_rng(seed)
    n = X.shape[0]
    if non_iid:
        # Covariate-shift partition: contiguous score bands are stored on workers.
        score = X[:, 0] + 0.35 * X[:, 1] + 0.05 * rng.normal(size=n)
        order = np.argsort(score)
    else:
        order = rng.permutation(n)
    return [(X[ind], y[ind]) for ind in np.array_split(order, workers)]


def spectral_lipschitz(workers: Sequence[Tuple[Array, Array]], mu: float) -> float:
    total = sum(Xm.shape[0] for Xm, _ in workers)
    constants = []
    for Xm, _ in workers:
        nm = Xm.shape[0]
        alpha_m = nm / total
        norm2 = float(np.linalg.norm(Xm, ord=2) ** 2)
        constants.append(alpha_m * norm2 / (2.0 * mu * nm))
    return max(constants)


def resolve_batch(batch: BatchSpec, k: int, n_local: int) -> int:
    if callable(batch):
        value = int(batch(k, n_local))
    elif batch is None:
        value = n_local
    else:
        value = int(batch)
    return min(max(value, 1), n_local)


@dataclass
class FitResult:
    coefficient: Array
    history: pd.DataFrame


def fss_admm(workers: Sequence[Tuple[Array, Array]], tau: float = 0.5,
             lam: float = 0.02, mu: float = 0.08, admm_penalty: float = 1.0,
             batch: BatchSpec = 32, iterations: int = 500, seed: int = 0,
             penalty: str = "lasso", alpha: float = 0.8,
             concavity: float = 3.7, noise_scale: float = 0.15,
             eval_data: Optional[Tuple[Array, Array, Array, Array]] = None,
             eval_every: int = 10) -> FitResult:
    """Synchronous federated stochastic smoothing ADMM.

    The practical step is eta_k = 0.98/(2L_mu + noise_scale*sqrt(k+1)),
    matching the decreasing-step structure in stochastic ADMM theory.
    """
    rng = np.random.default_rng(seed)
    M = len(workers)
    p = workers[0][0].shape[1]
    beta = np.zeros((M, p))
    z = np.zeros(p)
    u = np.zeros((M, p))
    total_n = sum(Xm.shape[0] for Xm, _ in workers)
    weights = np.array([Xm.shape[0] / total_n for Xm, _ in workers])
    L_mu = spectral_lipschitz(workers, mu)
    history = []
    samples_accessed = 0
    started = time.perf_counter()

    for k in range(iterations):
        eta_k = 0.98 / (2.0 * L_mu + noise_scale * math.sqrt(k + 1.0))
        for m, (Xm, ym) in enumerate(workers):
            nm = Xm.shape[0]
            b = resolve_batch(batch, k, nm)
            idx = rng.choice(nm, size=b, replace=False)
            residual = ym[idx] - Xm[idx] @ beta[m]
            local_grad = -(Xm[idx].T @ psi_tau_mu(residual, tau, mu)) / b
            grad = weights[m] * local_grad
            beta[m] = (beta[m] / eta_k + admm_penalty * (z - u[m]) - grad) / (
                1.0 / eta_k + admm_penalty
            )
            samples_accessed += b

        average = np.mean(beta + u, axis=0)
        z = prox_penalty(
            average,
            penalty=penalty,
            lam=lam,
            quadratic=M * admm_penalty,
            alpha=alpha,
            concavity=concavity,
        )
        u += beta - z

        if k % eval_every == 0 or k == iterations - 1:
            objective = np.nan
            smooth_obj = np.nan
            test_loss = np.nan
            if eval_data is not None:
                Xtr, ytr, Xte, yte = eval_data
                objective = pinball_objective(z, Xtr, ytr, tau, lam, penalty, alpha, concavity)
                smooth_obj = smooth_objective(z, Xtr, ytr, tau, mu, lam, penalty, alpha, concavity)
                test_loss = test_pinball(z, Xte, yte, tau)
            consensus = float(np.sqrt(np.mean(np.sum((beta - z) ** 2, axis=1))))
            stationarity = float(np.linalg.norm(z - prox_penalty(
                z - np.mean(u, axis=0), penalty, lam, M * admm_penalty, alpha, concavity
            )))
            history.append({
                "round": k + 1,
                "objective": objective,
                "smooth_objective": smooth_obj,
                "test_pinball": test_loss,
                "consensus": consensus,
                "stationarity_proxy": stationarity,
                "selected": int(np.sum(np.abs(z) > 1e-6)),
                "samples_accessed": samples_accessed,
                "time_seconds": time.perf_counter() - started,
                "step": eta_k,
                "L_mu": L_mu,
            })
    return FitResult(z, pd.DataFrame(history))


def distributed_prox_sgd(workers: Sequence[Tuple[Array, Array]], tau: float = 0.5,
                         lam: float = 0.02, mu: float = 0.08,
                         batch: BatchSpec = 32, iterations: int = 500,
                         seed: int = 0,
                         eval_data: Optional[Tuple[Array, Array, Array, Array]] = None,
                         eval_every: int = 10) -> FitResult:
    """Distributed mini-batch proximal SGD baseline without dual variables."""
    rng = np.random.default_rng(seed)
    p = workers[0][0].shape[1]
    z = np.zeros(p)
    total_n = sum(Xm.shape[0] for Xm, _ in workers)
    weights = np.array([Xm.shape[0] / total_n for Xm, _ in workers])
    L_mu = spectral_lipschitz(workers, mu)
    history = []
    samples_accessed = 0
    started = time.perf_counter()
    for k in range(iterations):
        step = 0.90 / (L_mu + 0.25 * math.sqrt(k + 1.0))
        global_grad = np.zeros(p)
        for m, (Xm, ym) in enumerate(workers):
            b = resolve_batch(batch, k, Xm.shape[0])
            idx = rng.choice(Xm.shape[0], size=b, replace=False)
            residual = ym[idx] - Xm[idx] @ z
            local_grad = -(Xm[idx].T @ psi_tau_mu(residual, tau, mu)) / b
            global_grad += weights[m] * local_grad
            samples_accessed += b
        z = soft_threshold(z - step * global_grad, step * lam)
        if k % eval_every == 0 or k == iterations - 1:
            objective = test_loss = np.nan
            if eval_data is not None:
                Xtr, ytr, Xte, yte = eval_data
                objective = pinball_objective(z, Xtr, ytr, tau, lam)
                test_loss = test_pinball(z, Xte, yte, tau)
            history.append({
                "round": k + 1,
                "objective": objective,
                "smooth_objective": np.nan,
                "test_pinball": test_loss,
                "consensus": 0.0,
                "stationarity_proxy": np.nan,
                "selected": int(np.sum(np.abs(z) > 1e-6)),
                "samples_accessed": samples_accessed,
                "time_seconds": time.perf_counter() - started,
                "step": step,
                "L_mu": L_mu,
            })
    return FitResult(z, pd.DataFrame(history))


def centralized_lp(X: Array, y: Array, tau: float, lam: float) -> Optional[Array]:
    if not SKLEARN_OK:
        return None
    model = QuantileRegressor(quantile=tau, alpha=lam, fit_intercept=False, solver="highs")
    model.fit(X, y)
    return np.asarray(model.coef_, dtype=float)


def selection_metrics(beta_hat: Array, beta_true: Array, threshold: float = 1e-5) -> Tuple[float, float, float]:
    truth = np.abs(beta_true) > 0
    selected = np.abs(beta_hat) > threshold
    tp = int(np.sum(truth & selected))
    fp = int(np.sum(~truth & selected))
    fn = int(np.sum(truth & ~selected))
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    f1 = 2.0 * precision * recall / max(precision + recall, 1e-15)
    return precision, recall, f1


def save_line_plot(df: pd.DataFrame, x: str, y: str, group: str, xlabel: str,
                   ylabel: str, filename: str, logy: bool = False) -> None:
    plt.figure(figsize=(5.5, 3.7))
    for name in df[group].drop_duplicates():
        subset = df[df[group] == name]
        if logy:
            plt.semilogy(subset[x], subset[y] + 1e-14, label=name, linewidth=1.7)
        else:
            plt.plot(subset[x], subset[y], label=name, linewidth=1.7)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.legend(frameon=False, fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, filename + ".pdf"))
    plt.savefig(os.path.join(FIG_DIR, filename + ".png"), dpi=400)
    plt.close()


def run_convergence() -> pd.DataFrame:
    Xtr, ytr, Xte, yte, _ = make_synth(seed=3, n=2600, p=120, s=12, error="t3")
    workers = split_workers(Xtr, ytr, 8, seed=10)
    configs = [
        ("Full-batch DSS-ADMM", None),
        ("DSS-ADMM, batch 64", 64),
        ("DSS-ADMM, batch 16", 16),
    ]
    frames = []
    for name, b in configs:
        fit = fss_admm(workers, tau=0.5, lam=0.018, mu=0.08, admm_penalty=1.0,
                       batch=b, iterations=600, seed=11, noise_scale=0.12,
                       eval_data=(Xtr, ytr, Xte, yte), eval_every=10)
        frame = fit.history.copy()
        frame["method"] = name
        frames.append(frame)
    baseline = distributed_prox_sgd(workers, tau=0.5, lam=0.018, mu=0.08,
                                    batch=64, iterations=600, seed=11,
                                    eval_data=(Xtr, ytr, Xte, yte), eval_every=10)
    frame = baseline.history.copy()
    frame["method"] = "Distributed prox-SGD, batch 64"
    frames.append(frame)
    df = pd.concat(frames, ignore_index=True)
    df.to_csv(os.path.join(RES_DIR, "convergence_results.csv"), index=False)
    save_line_plot(df, "samples_accessed", "objective", "method",
                   "sample-gradient evaluations", "original training objective",
                   "Fig2_objective_samples")
    admm_only = df[df["method"].str.contains("ADMM")]
    save_line_plot(admm_only, "round", "consensus", "method",
                   "communication rounds", "consensus residual",
                   "Fig3_consensus_rounds", logy=True)
    return df


def run_replicates(replicates: int = 10) -> pd.DataFrame:
    rows = []
    for seed in range(replicates):
        Xtr, ytr, Xte, yte, beta_true = make_synth(
            seed=100 + seed, n=2000, p=100, s=10, error="contaminated"
        )
        workers = split_workers(Xtr, ytr, 8, seed=seed)
        methods = [
            ("Full-batch DSS-ADMM", None),
            ("DSS-ADMM, batch 64", 64),
            ("DSS-ADMM, batch 16", 16),
        ]
        for name, b in methods:
            fit = fss_admm(workers, tau=0.5, lam=0.02, mu=0.08,
                           batch=b, iterations=600, seed=200 + seed,
                           noise_scale=0.12,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=600)
            last = fit.history.iloc[-1]
            precision, recall, f1 = selection_metrics(fit.coefficient, beta_true)
            rows.append({
                "replicate": seed,
                "method": name,
                "objective": last.objective,
                "test_pinball": last.test_pinball,
                "consensus": last.consensus,
                "selected": last.selected,
                "selection_precision": precision,
                "selection_recall": recall,
                "selection_f1": f1,
                "samples_accessed": last.samples_accessed,
                "time_seconds": last.time_seconds,
            })
        lp_beta = centralized_lp(Xtr, ytr, 0.5, 0.02)
        if lp_beta is not None:
            precision, recall, f1 = selection_metrics(lp_beta, beta_true)
            rows.append({
                "replicate": seed,
                "method": "Centralized LP",
                "objective": pinball_objective(lp_beta, Xtr, ytr, 0.5, 0.02),
                "test_pinball": test_pinball(lp_beta, Xte, yte, 0.5),
                "consensus": 0.0,
                "selected": int(np.sum(np.abs(lp_beta) > 1e-6)),
                "selection_precision": precision,
                "selection_recall": recall,
                "selection_f1": f1,
                "samples_accessed": np.nan,
                "time_seconds": np.nan,
            })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES_DIR, "replicate_results.csv"), index=False)
    summary = df.groupby("method", sort=False).agg(
        objective_mean=("objective", "mean"), objective_sd=("objective", "std"),
        test_mean=("test_pinball", "mean"), test_sd=("test_pinball", "std"),
        consensus_mean=("consensus", "mean"), selected_mean=("selected", "mean"),
        f1_mean=("selection_f1", "mean"), f1_sd=("selection_f1", "std"),
        samples_mean=("samples_accessed", "mean"), time_mean=("time_seconds", "mean"),
    ).reset_index()
    summary.to_csv(os.path.join(RES_DIR, "replicate_summary.csv"), index=False)
    return summary


def run_heterogeneity(replicates: int = 8) -> pd.DataFrame:
    rows = []
    for seed in range(replicates):
        Xtr, ytr, Xte, yte, _ = make_synth(seed=500 + seed, n=2600, p=100, s=10, error="t3")
        for non_iid, label in [(False, "IID partition"), (True, "Non-IID partition")]:
            workers = split_workers(Xtr, ytr, 8, seed=seed, non_iid=non_iid)
            fit = fss_admm(workers, tau=0.5, lam=0.018, mu=0.08, batch=64,
                           iterations=700, seed=700 + seed, noise_scale=0.12,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=450)
            last = fit.history.iloc[-1]
            rows.append({
                "replicate": seed,
                "partition": label,
                "objective": last.objective,
                "test_pinball": last.test_pinball,
                "consensus": last.consensus,
                "selected": last.selected,
            })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES_DIR, "heterogeneity_results.csv"), index=False)
    summary = df.groupby("partition").agg(
        objective_mean=("objective", "mean"), objective_sd=("objective", "std"),
        test_mean=("test_pinball", "mean"), test_sd=("test_pinball", "std"),
        consensus_mean=("consensus", "mean"), selected_mean=("selected", "mean"),
    ).reset_index()
    summary.to_csv(os.path.join(RES_DIR, "heterogeneity_summary.csv"), index=False)
    return summary


def run_scaling() -> pd.DataFrame:
    rows = []
    for n in [1200, 3600, 7200]:
        Xtr, ytr, Xte, yte, _ = make_synth(seed=50 + n, n=n, p=80, s=8, error="t3")
        workers = split_workers(Xtr, ytr, 8, seed=1)
        for label, b in [("Batch 32", 32), ("Batch 128", 128), ("Full batch", None)]:
            fit = fss_admm(workers, tau=0.5, lam=0.02, mu=0.08, batch=b,
                           iterations=350, seed=42, noise_scale=0.12,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=350)
            last = fit.history.iloc[-1]
            rows.append({
                "n": n,
                "method": label,
                "objective": last.objective,
                "test_pinball": last.test_pinball,
                "samples_accessed": last.samples_accessed,
                "time_seconds": last.time_seconds,
                "selected": last.selected,
            })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES_DIR, "scaling_results.csv"), index=False)
    plt.figure(figsize=(5.5, 3.7))
    positions = np.arange(3)
    width = 0.24
    n_values = [1200, 3600, 7200]
    for j, method in enumerate(df["method"].drop_duplicates()):
        subset = df[df["method"] == method].set_index("n").loc[n_values]
        plt.bar(positions + (j - 1) * width, subset["time_seconds"], width=width, label=method)
    plt.xticks(positions, [str(v) for v in n_values])
    plt.xlabel("sample size")
    plt.ylabel("serial emulation time (seconds)")
    plt.legend(frameon=False, fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "Fig4_scaling_time.pdf"))
    plt.savefig(os.path.join(FIG_DIR, "Fig4_scaling_time.png"), dpi=400)
    plt.close()
    return df


def run_nonconvex(replicates: int = 8) -> pd.DataFrame:
    rows = []
    for seed in range(replicates):
        Xtr, ytr, Xte, yte, beta_true = make_synth(
            seed=900 + seed, n=1200, p=80, s=8, error="contaminated"
        )
        workers = split_workers(Xtr, ytr, 8, seed=seed)
        for penalty, a in [("lasso", 3.7), ("mcp", 3.0), ("scad", 3.7)]:
            # Full local gradients are used in the nonconvex extension experiment,
            # satisfying the vanishing-noise condition as a deterministic special case.
            fit = fss_admm(workers, tau=0.5, lam=0.018, mu=0.08,
                           admm_penalty=1.0, batch=None, iterations=450,
                           seed=1000 + seed, penalty=penalty, concavity=a,
                           noise_scale=0.08,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=450)
            last = fit.history.iloc[-1]
            precision, recall, f1 = selection_metrics(fit.coefficient, beta_true)
            rows.append({
                "replicate": seed,
                "penalty": penalty.upper(),
                "objective": last.objective,
                "test_pinball": last.test_pinball,
                "selected": last.selected,
                "selection_precision": precision,
                "selection_recall": recall,
                "selection_f1": f1,
                "consensus": last.consensus,
            })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES_DIR, "nonconvex_results.csv"), index=False)
    summary = df.groupby("penalty", sort=False).agg(
        objective_mean=("objective", "mean"), objective_sd=("objective", "std"),
        test_mean=("test_pinball", "mean"), test_sd=("test_pinball", "std"),
        selected_mean=("selected", "mean"), f1_mean=("selection_f1", "mean"),
        f1_sd=("selection_f1", "std"), consensus_mean=("consensus", "mean"),
    ).reset_index()
    summary.to_csv(os.path.join(RES_DIR, "nonconvex_summary.csv"), index=False)
    return summary


def run_diabetes(replicates: int = 20) -> pd.DataFrame:
    rows = []
    if not SKLEARN_OK:
        pd.DataFrame(rows).to_csv(os.path.join(RES_DIR, "diabetes_results.csv"), index=False)
        return pd.DataFrame(rows)
    data = load_diabetes()
    X = np.asarray(data.data, dtype=float)
    y = np.asarray(data.target, dtype=float)
    for seed in range(replicates):
        Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=seed)
        Xtr, Xte = standardize_train_test(Xtr, Xte)
        ytr, yte = standardize_y(ytr, yte)
        workers = split_workers(Xtr, ytr, 4, seed=seed, non_iid=True)
        for tau in [0.25, 0.50, 0.75]:
            fit = fss_admm(workers, tau=tau, lam=0.012, mu=0.06, batch=16,
                           iterations=650, seed=1200 + seed, noise_scale=0.10,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=650)
            last = fit.history.iloc[-1]
            lp_beta = centralized_lp(Xtr, ytr, tau, 0.012)
            rows.append({
                "replicate": seed,
                "tau": tau,
                "method": "DSS-ADMM",
                "test_pinball": last.test_pinball,
                "selected": last.selected,
                "consensus": last.consensus,
            })
            if lp_beta is not None:
                rows.append({
                    "replicate": seed,
                    "tau": tau,
                    "method": "Centralized LP",
                    "test_pinball": test_pinball(lp_beta, Xte, yte, tau),
                    "selected": int(np.sum(np.abs(lp_beta) > 1e-6)),
                    "consensus": 0.0,
                })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES_DIR, "diabetes_results.csv"), index=False)
    summary = df.groupby(["tau", "method"], sort=False).agg(
        test_mean=("test_pinball", "mean"), test_sd=("test_pinball", "std"),
        selected_mean=("selected", "mean"), selected_sd=("selected", "std"),
        consensus_mean=("consensus", "mean"),
    ).reset_index()
    summary.to_csv(os.path.join(RES_DIR, "diabetes_summary.csv"), index=False)
    return summary



def run_engel(replicates: int = 8) -> pd.DataFrame:
    """Distributed Engel food-expenditure experiment used in the manuscript.

    Statsmodels ships the Engel dataset locally, so this experiment does not
    require an internet connection. Six polynomial features of log income are
    used, matching the manuscript description.
    """
    rows = []
    if not STATSMODELS_OK:
        pd.DataFrame(rows).to_csv(os.path.join(RES_DIR, "engel_results.csv"), index=False)
        return pd.DataFrame(rows)
    data = sm.datasets.engel.load_pandas().data
    income = np.log(np.asarray(data["income"], dtype=float))
    y = np.asarray(data["foodexp"], dtype=float)
    X = np.column_stack([income ** degree for degree in range(1, 7)])
    for seed in range(replicates):
        rng = np.random.default_rng(seed)
        order = rng.permutation(len(y))
        cut = int(0.70 * len(y))
        tr, te = order[:cut], order[cut:]
        Xtr, Xte = standardize_train_test(X[tr], X[te])
        ytr, yte = standardize_y(y[tr], y[te])
        workers = split_workers(Xtr, ytr, 4, seed=seed, non_iid=True)
        for tau in [0.25, 0.50, 0.75]:
            fit = fss_admm(workers, tau=tau, lam=0.010, mu=0.06, batch=16,
                           iterations=650, seed=1600 + seed, noise_scale=0.10,
                           eval_data=(Xtr, ytr, Xte, yte), eval_every=650)
            last = fit.history.iloc[-1]
            rows.append({
                "replicate": seed, "tau": tau, "method": "DSS-ADMM",
                "test_pinball": last.test_pinball,
                "selected": last.selected, "consensus": last.consensus,
            })
            lp_beta = centralized_lp(Xtr, ytr, tau, 0.010)
            if lp_beta is not None:
                rows.append({
                    "replicate": seed, "tau": tau, "method": "Centralized LP",
                    "test_pinball": test_pinball(lp_beta, Xte, yte, tau),
                    "selected": int(np.sum(np.abs(lp_beta) > 1e-6)),
                    "consensus": 0.0,
                })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES_DIR, "engel_results.csv"), index=False)
    if not df.empty:
        summary = df.groupby(["tau", "method"], sort=False).agg(
            test_mean=("test_pinball", "mean"), test_sd=("test_pinball", "std"),
            selected_mean=("selected", "mean"), consensus_mean=("consensus", "mean"),
        ).reset_index()
        summary.to_csv(os.path.join(RES_DIR, "engel_summary.csv"), index=False)
        return summary
    return df


def run_smoke() -> dict:
    """Fast deterministic validation of the numerical pipeline (<1 minute)."""
    started = time.perf_counter()
    Xtr, ytr, Xte, yte, beta_true = make_synth(
        seed=20260806, n=240, p=12, s=3, error="contaminated"
    )
    workers = split_workers(Xtr, ytr, workers=4, seed=17, non_iid=True)
    fit = fss_admm(
        workers, tau=0.5, lam=0.02, mu=0.10, batch=8,
        iterations=25, seed=31, noise_scale=0.08,
        eval_data=(Xtr, ytr, Xte, yte), eval_every=5,
    )
    last = fit.history.iloc[-1]
    precision, recall, f1 = selection_metrics(fit.coefficient, beta_true)
    values = {
        "objective": float(last.objective),
        "test_pinball": float(last.test_pinball),
        "consensus": float(last.consensus),
        "selected": int(last.selected),
        "selection_precision": precision,
        "selection_recall": recall,
        "selection_f1": f1,
        "iterations": 25,
        "workers": 4,
        "finite": bool(np.all(np.isfinite(fit.coefficient))),
        "runtime_seconds": time.perf_counter() - started,
    }
    if not values["finite"]:
        raise RuntimeError("Smoke test produced non-finite coefficients")
    pd.DataFrame([values]).to_csv(os.path.join(RES_DIR, "smoke_test_results.csv"), index=False)
    with open(os.path.join(RES_DIR, "smoke_test_results.json"), "w", encoding="utf-8") as handle:
        json.dump(values, handle, indent=2)
    print(json.dumps(values, indent=2))
    return values

def draw_architecture() -> None:
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

    plt.figure(figsize=(7.2, 3.8))
    ax = plt.gca()
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis("off")
    worker_x = [0.7, 3.1, 5.5, 7.9]
    for j, x in enumerate(worker_x, start=1):
        box = FancyBboxPatch((x, 0.6), 1.4, 1.6, boxstyle="round,pad=0.08")
        ax.add_patch(box)
        ax.text(x + 0.7, 1.65, f"Worker {j}", ha="center", va="center", fontsize=10)
        ax.text(x + 0.7, 1.15, "local mini-batch\nstochastic gradient", ha="center", va="center", fontsize=8)
        ax.add_patch(FancyArrowPatch((x + 0.7, 2.25), (5.0, 3.75), arrowstyle="->", mutation_scale=11))
        ax.add_patch(FancyArrowPatch((5.0, 3.45), (x + 0.7, 2.25), arrowstyle="->", mutation_scale=11))
    server = FancyBboxPatch((3.9, 3.75), 2.2, 1.55, boxstyle="round,pad=0.10")
    ax.add_patch(server)
    ax.text(5.0, 4.75, "Coordinator", ha="center", va="center", fontsize=11)
    ax.text(5.0, 4.25, "proximal aggregation\nand consensus broadcast", ha="center", va="center", fontsize=8)
    ax.text(5.0, 5.65, "Raw observations remain local", ha="center", va="center", fontsize=10)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "Fig1_architecture.pdf"))
    plt.savefig(os.path.join(FIG_DIR, "Fig1_architecture.png"), dpi=400)
    plt.close()



def main(quick: bool = False, smoke: bool = False, experiment: str = "all") -> None:
    if smoke:
        run_smoke()
        return
    started = time.perf_counter()
    outputs = {}
    if experiment in {"all", "convergence"}:
        draw_architecture()
        outputs["convergence"] = run_convergence()
    if experiment in {"all", "replicates"}:
        outputs["replicates"] = run_replicates(5 if quick else 10)
    if experiment in {"all", "heterogeneity"}:
        outputs["heterogeneity"] = run_heterogeneity(4 if quick else 8)
    if experiment in {"all", "scaling"}:
        outputs["scaling"] = run_scaling()
    if experiment in {"all", "nonconvex"}:
        outputs["nonconvex"] = run_nonconvex(4 if quick else 8)
    if experiment in {"all", "diabetes"}:
        outputs["diabetes"] = run_diabetes(8 if quick else 20)
    if experiment in {"all", "engel"}:
        outputs["engel"] = run_engel(4 if quick else 8)
    metadata = {
        "runtime_seconds": time.perf_counter() - started,
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "sklearn_available": SKLEARN_OK,
        "sklearn_version": None if sklearn is None else sklearn.__version__,
        "statsmodels_available": STATSMODELS_OK,
        "quick_mode": quick,
        "experiment": experiment,
        "seed_policy": "All experiment seeds are explicit in run_experiments.py",
    }
    with open(os.path.join(RES_DIR, "run_metadata.json"), "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2)
    print(json.dumps(metadata, indent=2))
    for name, output in outputs.items():
        print(f"\n{name}\n", output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Reproduce DSS-ADMM numerical experiments")
    parser.add_argument("--quick", action="store_true", help="Use fewer replications")
    parser.add_argument("--smoke", action="store_true", help="Run a tiny validation in under one minute")
    parser.add_argument(
        "--experiment",
        choices=["all", "convergence", "replicates", "heterogeneity", "scaling", "nonconvex", "diabetes", "engel"],
        default="all",
        help="Run one experiment family or the complete suite",
    )
    args = parser.parse_args()
    main(quick=args.quick, smoke=args.smoke, experiment=args.experiment)
