#!/usr/bin/env python3
"""Lightweight integrity checks for the DSS-ADMM reproducibility bundle."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"


def check_csv(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(path)
    frame = pd.read_csv(path)
    if frame.empty:
        raise ValueError(f"{path.name} is empty")
    numeric = frame.select_dtypes(include=[np.number])
    if not numeric.empty:
        values = numeric.to_numpy(dtype=float)
        if np.isinf(values).any():
            raise ValueError(f"{path.name} contains infinite numeric entries")
        if np.isnan(values).all():
            raise ValueError(f"{path.name} has no finite numeric output")


def main(smoke_only: bool) -> None:
    smoke_json = RESULTS / "smoke_test_results.json"
    smoke_csv = RESULTS / "smoke_test_results.csv"
    check_csv(smoke_csv)
    values = json.loads(smoke_json.read_text(encoding="utf-8"))
    if not values.get("finite", False):
        raise ValueError("smoke test did not report finite coefficients")
    if not smoke_only:
        expected = [
            "convergence_results.csv",
            "replicate_results.csv",
            "heterogeneity_results.csv",
            "scaling_results.csv",
            "nonconvex_results.csv",
        ]
        for name in expected:
            check_csv(RESULTS / name)
        optional_extended = [
            "worker_smoothing_results.csv",
            "regularization_batch_results.csv",
            "robustness_dimension_results.csv",
            "imbalance_correlation_results.csv",
            "nonconvex_batch_schedule_results.csv",
        ]
        for name in optional_extended:
            path = RESULTS / name
            if path.exists():
                check_csv(path)
    print("Reproducibility output checks passed.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke-only", action="store_true")
    args = parser.parse_args()
    main(args.smoke_only)
