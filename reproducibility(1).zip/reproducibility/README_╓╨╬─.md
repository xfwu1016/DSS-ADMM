# DSS-ADMM 实验复现说明

本目录提供论文 **Distributed Stochastic Smoothing ADMM for Penalized
Quantile Regression** 的算法实现、仿真实验、真实数据实验、表格数值和投稿图片。

## 安装环境

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

也可使用 `environment.yml` 创建 Conda 环境。

## 快速核验

```bash
./run_smoke.sh
```

该命令运行一个小规模确定性测试，并检查系数、目标函数、预测损失和一致性残差是否为有限值。

## 完整运行

```bash
./run_all.sh
```

较快的核验运行：

```bash
python code/run_experiments.py --quick --experiment all
python code/run_extended_experiments.py --quick --experiment all
python code/verify_outputs.py
```

还可以通过 `--experiment` 分别运行 `convergence`、`replicates`、
`heterogeneity`、`scaling`、`nonconvex`、`diabetes` 或 `engel`。

- `precomputed_results/` 保存论文表格使用的数值；
- `precomputed_figures/` 保存论文正式图片；
- `results/` 和 `figures/` 保存重新运行代码生成的输出；
- `code/figure1_source.tex` 是图1的精确 TikZ 源，仅加入颜色，不改变第12版的节点位置、箭头、文字和电脑底座结构。

`--quick` 使用较少重复次数，因此其数值不应与论文正式重复次数的汇总值逐位相同。完整代码保留了论文所需的算法更新、数据生成和实验机制。

程序采用单进程模拟横向分布式计算，能够复现数值结果、样本梯度访问次数和一致性行为，但不将串行时间解释为真实多机集群加速比。

图4--图8对应的补充敏感性实验由 `code/run_extended_experiments.py` 复现，包括节点数与光滑参数、正则化与批大小、误差稳健性与维数、节点样本不平衡与相关性、以及MCP/SCAD的批量调度残差实验。
