#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 code/run_experiments.py --experiment all
python3 code/run_extended_experiments.py --experiment all
python3 code/verify_outputs.py
